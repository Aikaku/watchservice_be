package com.watchserviceagent.watchservice_agent.scan.domain;

public enum ScanStatus {
    RUNNING,
    PAUSED,
    DONE,
    ERROR
}
